const questions = [
  {
    q: "Which is the largest city in Somalia?",
    a: ["Muqdisho", "Hargeysa", "Baydhabo", "Kismaayo"],
    c: 0
  },
  {
    q: "Which continent is Somalia in?",
    a: ["Asia", "Europe", "Africa", "America"],
    c: 2
  },
  {
    q: "How many points does the Somali flag star have?",
    a: ["One", "Three", "Four", "Five"],
    c: 3
  },
  {
    q: "What is the national language of Somalia?",
    a: ["Arabic", "English", "Somali", "Swahili"],
    c: 2
  }
];

let index = 0;
let score = 0;

function showQuestion() {
  document.getElementById("question").innerText = questions[index].q;
  document.getElementById("a0").innerText = questions[index].a[0];
  document.getElementById("a1").innerText = questions[index].a[1];
  document.getElementById("a2").innerText = questions[index].a[2];
  document.getElementById("a3").innerText = questions[index].a[3];
}

function checkAnswer(answer) {
  if (answer === questions[index].c) {
    score++;
    alert("Correct ✅");
  } else {
    alert("Wrong ❌");
  }
  document.getElementById("score").innerText = "Score: " + score;
}

function nextQuestion() {
  index++;
  if (index < questions.length) {
    showQuestion();
  } else {
    document.getElementById("question").innerText =
      "Quiz Finished! Final Score: " + score + "/" + questions.length;
  }
}

showQuestion();

